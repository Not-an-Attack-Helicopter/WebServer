#!/usr/bin/env ruby

# ============================================================================
# SWOT Analysis
#
# A completely serious Strategic Assessment Tool.
#
# Strengths
# Weaknesses
# Opportunities
# Threats
#
# CGI version. No frameworks. No consultants.
# ============================================================================


require "cgi"


cgi = CGI.new


# ============================================================================
# Helpers
# ============================================================================

def h(text)
    CGI.escapeHTML(text.to_s)
end


def param(cgi, name)
    value = cgi.params[name]
    return "" if value.nil? || value.empty?

    value.first.to_s.strip
end


def selected(cgi, name, value)
    param(cgi, name) == value ? " selected" : ""
end


def checked(cgi, name, value)
    param(cgi, name) == value ? " checked" : ""
end


def textarea_value(cgi, name)
    h(param(cgi, name))
end


# ============================================================================
# Assessment
# ============================================================================

def analyse(cgi)

    strengths = param(cgi, "strengths")
    weaknesses = param(cgi, "weaknesses")
    opportunities = param(cgi, "opportunities")
    threats = param(cgi, "threats")

    strength_level = param(cgi, "strength_level").to_i
    weakness_level = param(cgi, "weakness_level").to_i
    opportunity_level = param(cgi, "opportunity_level").to_i
    threat_level = param(cgi, "threat_level").to_i

    # --------------------------------------------------------------------------
    # Basic scores
    #
    # Strengths and opportunities increase the score.
    # Weaknesses and threats decrease it.
    # --------------------------------------------------------------------------

    score =
            (strength_level * 2) +
            (opportunity_level * 2) -
            (weakness_level * 2) -
            (threat_level * 2)

    # Small bonus for actually providing something in each section.
    score += 2 unless strengths.empty?
    score += 2 unless weaknesses.empty?
    score += 2 unless opportunities.empty?
    score += 2 unless threats.empty?

    # Clamp the result.
    score = [[score, -36].max, 36].min


    # --------------------------------------------------------------------------
    # Determine overall assessment
    # --------------------------------------------------------------------------

    if score >= 25
        verdict = "PROCEED WITH CONFIDENCE"
        verdict_class = "excellent"

        interpretation =
                "The strategic situation appears unusually favourable. " \
                "Someone has apparently been paying attention."

    elsif score >= 12
        verdict = "PROCEED, BUT KEEP AN EYE ON THINGS"
        verdict_class = "good"

        interpretation =
                "There are more things going right than wrong. " \
                "This is generally considered a good sign."

    elsif score >= 0
        verdict = "PROCEED WITH CAUTION"
        verdict_class = "neutral"

        interpretation =
                "The situation is broadly balanced. " \
                "Unfortunately, this means there is no obvious excuse if it goes wrong."

    elsif score >= -12
        verdict = "FURTHER ANALYSIS RECOMMENDED"
        verdict_class = "warning"

        interpretation =
                "The weaknesses and threats are beginning to outweigh the positives. " \
                "A meeting may be required."

    elsif score >= -25
        verdict = "STRATEGIC CONCERN"
        verdict_class = "danger"

        interpretation =
                "The current situation contains several warning signs. " \
                "Consider mitigation before somebody asks why this happened."

    else
        verdict = "ABORT STRATEGIC INITIATIVE"
        verdict_class = "critical"

        interpretation =
                "The numbers have become sufficiently unpleasant that " \
                "continuing would require either courage or poor judgment."

    end


    # --------------------------------------------------------------------------
    # Management interpretation
    # --------------------------------------------------------------------------

    management = []

    if strength_level >= 4
        management << "Leverage existing strengths."
    end

    if weakness_level >= 4
        management << "Address weaknesses before they become features."
    end

    if opportunity_level >= 4
        management << "Investigate opportunities while enthusiasm remains."
    end

    if threat_level >= 4
        management << "Identify mitigation strategies for significant threats."
    end

    if threat_level >= 3 && weakness_level >= 3
        management << "Do not make any irreversible changes on a Friday afternoon."
    end

    if strengths.empty? && weaknesses.empty? &&
     opportunities.empty? && threats.empty?
        management << "Nobody entered any information. This is technically a strategy."
    end

    if management.empty?
        management << "Continue monitoring the situation."
    end


    {
        strengths: strengths,
        weaknesses: weaknesses,
        opportunities: opportunities,
        threats: threats,

        strength_level: strength_level,
        weakness_level: weakness_level,
        opportunity_level: opportunity_level,
        threat_level: threat_level,

        score: score,
        verdict: verdict,
        verdict_class: verdict_class,
        interpretation: interpretation,
        management: management
    }

end


# ============================================================================
# Output
# ============================================================================

puts cgi.header("text/html; charset=utf-8")


# ============================================================================
# Show results if submitted
# ============================================================================

if cgi.request_method == "POST" &&
   cgi.params["analyse"] &&
   !cgi.params["analyse"].empty?

    result = analyse(cgi)

    puts <<~HTML
    <!DOCTYPE html>
    <html lang="en">
    <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="icon" type="image/x-icon" href="/images/icons/favicon.ico">
    <link rel="icon" type="image/png" sizes="32x32" href="/images/icons/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="/images/icons/favicon-16x16.png">
    <link rel="apple-touch-icon" sizes="180x180" href="/images/icons/apple-touch-icon.png">
    <link rel="manifest" href="/images/icons/site.webmanifest">
    <link rel="stylesheet" href="/css/swot.css">

    <title>SWOT Analysis</title>
    </head>

    <body>

    <main class="container">

    <header>
    <h1>SWOT Analysis</h1>
    <p class="subtitle">
    Strategic Weaknesses, Opportunities, Threats &amp; Stuff
    </p>
    </header>

    <section class="result">

    <h2>STRATEGIC ASSESSMENT</h2>

    <div class="score">
    <span>Overall score</span>
    <strong>#{result[:score]}</strong>
    </div>

    <div class="verdict #{result[:verdict_class]}">
    #{h(result[:verdict])}
    </div>

    <p class="interpretation">
    #{h(result[:interpretation])}
    </p>


    <h2>SWOT SUMMARY</h2>

    <div class="swot-grid">

    <section class="swot-card strengths">
    <h3>Strengths</h3>

    <p>
    #{result[:strength_level]}/5
    </p>

    <div class="answer">
    #{h(result[:strengths]).gsub("\n", "<br>")}
    </div>
    </section>


    <section class="swot-card weaknesses">
    <h3>Weaknesses</h3>

    <p>
    #{result[:weakness_level]}/5
    </p>

    <div class="answer">
    #{h(result[:weaknesses]).gsub("\n", "<br>")}
    </div>
    </section>


    <section class="swot-card opportunities">
    <h3>Opportunities</h3>

    <p>
    #{result[:opportunity_level]}/5
    </p>

    <div class="answer">
    #{h(result[:opportunities]).gsub("\n", "<br>")}
    </div>
    </section>


    <section class="swot-card threats">
    <h3>Threats</h3>

    <p>
    #{result[:threat_level]}/5
    </p>

    <div class="answer">
    #{h(result[:threats]).gsub("\n", "<br>")}
    </div>
    </section>

    </div>


    <h2>MANAGEMENT INTERPRETATION</h2>

    <div class="management">

    <ul>
    HTML

    result[:management].each do |item|
        puts "                <li>#{h(item)}</li>"
    end

    puts <<~HTML
    </ul>

    </div>


    <div class="actions">
    <form method="get" action="swot.rb">
    <button type="submit">
    Start over
    </button>
    </form>
    </div>

    </section>

    </main>

    </body>
    </html>
    HTML

    exit
end


# ============================================================================
# Questionnaire
# ============================================================================

puts <<~HTML
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<link rel="stylesheet" href="/css/swot.css">

<title>SWOT Analysis</title>
</head>

<body>

<main class="container">

<header>
<h1>SWOT Analysis</h1>

<p class="subtitle">
Strengths, Weaknesses, Opportunities, Threats &amp; Stuff
</p>

<p class="description">
A completely serious strategic assessment tool for determining
whether your current situation is brilliant, questionable,
or something that should probably not be discussed in public.
</p>
</header>


<form method="post" action="swot.rb">

<section class="questionnaire">

<h2>STRENGTHS</h2>

<p>
What is this operation surprisingly good at?
</p>

<textarea
name="strengths"
rows="5"
placeholder="Reliable backups, competent people, surprisingly stable server..."
></textarea>

<label for="strength_level">
Overall strength
</label>

<select name="strength_level" id="strength_level">
<option value="1">1 — Barely a strength</option>
<option value="2">2 — Somewhat useful</option>
<option value="3" selected>3 — Reasonably strong</option>
<option value="4">4 — Quite strong</option>
<option value="5">5 — Suspiciously competent</option>
</select>


<h2>WEAKNESSES</h2>

<p>
What could go wrong, and how long has everyone known about it?
</p>

<textarea
name="weaknesses"
rows="5"
placeholder="No documentation, single point of failure, legacy system nobody understands..."
></textarea>

<label for="weakness_level">
Overall weakness
</label>

<select name="weakness_level" id="weakness_level">
<option value="1">1 — Barely noticeable</option>
<option value="2">2 — Minor concern</option>
<option value="3" selected>3 — Needs attention</option>
<option value="4">4 — Significant problem</option>
<option value="5">5 — Please do not touch anything</option>
</select>


<h2>OPPORTUNITIES</h2>

<p>
What could be improved if somebody actually had the time?
</p>

<textarea
name="opportunities"
rows="5"
placeholder="Automation, documentation, upgrades, eliminating manual work..."
></textarea>

<label for="opportunity_level">
Overall opportunity
</label>

<select name="opportunity_level" id="opportunity_level">
<option value="1">1 — Not really</option>
<option value="2">2 — Possibly</option>
<option value="3" selected>3 — Worth investigating</option>
<option value="4">4 — Good opportunity</option>
<option value="5">5 — Why haven't we done this already?</option>
</select>


<h2>THREATS</h2>

<p>
What might break, disappear, expire, or become somebody else's problem?
</p>

<textarea
name="threats"
rows="5"
placeholder="Hardware failure, expired certificate, vendor disappearing, Bob retiring..."
></textarea>

<label for="threat_level">
Overall threat level
</label>

<select name="threat_level" id="threat_level">
<option value="1">1 — Practically theoretical</option>
<option value="2">2 — Unlikely</option>
<option value="3" selected>3 — Plausible</option>
<option value="4">4 — Significant</option>
<option value="5">5 — Already happening</option>
</select>


<div class="actions">

<button type="submit" name="analyse" value="1">
Perform Strategic Analysis
</button>

<button
type="reset"
class="secondary"
>
Clear
</button>

</div>

</section>

</form>


<footer>
<p>
SWOT analysis is a strategic planning technique.
This implementation is not a substitute for professional
management consulting, which is probably for the best.
</p>
</footer>

</main>

</body>
</html>
HTML

#!/usr/bin/env python3

from datetime import datetime
import html


# ============================================================================
# Is It Friday Yet?
# ============================================================================

now = datetime.now()

day = now.strftime("%A")
date = now.strftime("%A, %d %B %Y")
time = now.strftime("%H:%M:%S")

# Monday = 0
# Friday = 4

# ============================================================================
# Messages
# ============================================================================

if now.weekday() == 0:              # Monday

    title = "NO."
    message = "Absolutely not."
    submessage = "It's Monday. This is going to take a while."

elif now.weekday() == 1:            # Tuesday

    title = "NO."
    message = "It's Tuesday."
    submessage = "Keep going."

elif now.weekday() == 2:            # Wednesday

    title = "NO."
    message = "But we're getting somewhere."
    submessage = "You've made it halfway. Probably."

elif now.weekday() == 3:            # Thursday

    title = "ALMOST."
    message = "It's Thursday."
    submessage = "Friday is tomorrow. You can almost taste it."

elif now.weekday() == 4:            # Friday

    if now.hour < 12:

        title = "YES!"
        message = "IT IS FRIDAY!"
        submessage = "You made it. Don't screw this up."

    else:

        title = "YES!"
        message = "DON'T WASTE IT."
        submessage = "It is Friday afternoon. The weekend is approaching."

elif now.weekday() == 5:            # Saturday

    title = "NO."
    message = "You missed it."
    submessage = "Friday has left the building."

elif now.weekday() == 6:            # Sunday

    title = "NO."
    message = "It's Sunday."
    submessage = "Oh no! Monday is coming."

# ============================================================================
# HTML output
# ============================================================================

print("Content-Type: text/html; charset=UTF-8")
print()

print(f"""<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="utf-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <link
        rel="icon"
        type="image/x-icon"
        href="/images/icons/favicon.ico"
    >

    <link
        rel="icon"
        type="image/png"
        sizes="32x32"
        href="/images/icons/favicon-32x32.png"
    >

    <link
        rel="icon"
        type="image/png"
        sizes="16x16"
        href="/images/icons/favicon-16x16.png"
    >

    <link
        rel="apple-touch-icon"
        sizes="180x180"
        href="/images/icons/apple-touch-icon.png"
    >

    <link
        rel="manifest"
        href="/images/icons/site.webmanifest"
    >

    <link
        rel="stylesheet"
        href="/css/friday.css"
    >

    <title>Is It Friday Yet?</title>

</head>

<body>

<div class="container">

    <h1>Is It Friday Yet?</h1>

    <div class="answer">
        {html.escape(title)}
    </div>

    <div class="message">
        {html.escape(message)}
    </div>

    <div class="submessage">
        {html.escape(submessage)}
    </div>

    <div class="date">
        Server time: {html.escape(date)}<br>
        {html.escape(time)}
    </div>

    <br>

    <div class="refresh">

        <form method="get">

            <button type="submit">
                Check Again
            </button>

        </form>

    </div>

</div>

</body>

</html>
""")

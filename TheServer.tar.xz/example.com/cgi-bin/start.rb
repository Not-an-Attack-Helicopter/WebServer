#!/usr/bin/env ruby

# ============================================================================
# START
#
# Short-Term Assessment of Risk and Treatability
#
# Sysadmin Edition
#
# This is a parody. It is not the clinical START instrument.
# ============================================================================

require "cgi"

cgi = CGI.new

# ----------------------------------------------------------------------------
# Helpers
# ----------------------------------------------------------------------------

def html_escape(text)
  CGI.escapeHTML(text.to_s)
end

def param(cgi, name)
  cgi.params[name]&.first.to_s
end

def risk_level(score)
  return "EXTREME" if score >= 80
  return "HIGH" if score >= 60
  return "MODERATE" if score >= 35

  "LOW"
end

def select_field(id, name, options)
  html = +"<select id=\"#{html_escape(id)}\" name=\"#{html_escape(name)}\">\n"

  options.each do |value, label|
    html << "    <option value=\"#{html_escape(value)}\">"
    html << html_escape(label)
    html << "</option>\n"
  end

  html << "</select>"
  html
end

def html_header(cgi)
  puts cgi.header(
    "type" => "text/html",
    "charset" => "UTF-8"
  )
end

# ----------------------------------------------------------------------------
# Read submitted values
# ----------------------------------------------------------------------------

fields = %w[
  activity
  environment
  backup
  rollback
  sleep
  documentation
  staging
  maintenance
  monitoring
  console
  experience
  peer_review
  change_size
  urgency
  five_minutes
  exact_change
  coffee
]

v = {}

fields.each do |field|
  v[field] = param(cgi, field)
end

# ----------------------------------------------------------------------------
# First visit
# ----------------------------------------------------------------------------

unless param(cgi, "submitted") == "1"

  html_header(cgi)

  environment_options = [
    ["development", "Development"],
    ["staging",     "Staging"],
    ["production",  "Production"]
  ]

  backup_options = [
    ["verified", "Backup exists and I have successfully restored it"],
    ["exists",   "Backup exists, but I have never tested the restore"],
    ["none",     "There is no backup"],
    ["unknown",  "I assume there is a backup"]
  ]

  rollback_options = [
    ["tested_auto",   "Tested automated rollback"],
    ["tested_manual", "Tested manual rollback"],
    ["documented",    "Documented rollback, never tested"],
    ["known",         "I know roughly how to undo it"],
    ["none",          "There is no rollback procedure"]
  ]

  sleep_options = [
    ["7plus", "7+ hours"],
    ["5to7",  "5–7 hours"],
    ["3to5",  "3–5 hours"],
    ["under3", "Less than 3 hours"],
    ["none",  "Sleep is a distant memory"]
  ]

  coffee_options = [
    ["0",      "0"],
    ["1",      "1"],
    ["2",      "2"],
    ["3",      "3"],
    ["4",      "4"],
    ["5",      "5"],
    ["6",      "6"],
    ["7",      "7"],
    ["8",      "8"],
    ["9",      "9"],
    ["10plus", "10+"]
  ]

  documentation_options = [
    ["excellent", "Excellent — a stranger could follow it"],
    ["good",      "Good — mostly complete"],
    ["adequate",  "Adequate — I know what I need to know"],
    ["poor",      "Poor — I wrote most of it myself"],
    ["none",      "None — knowledge resides entirely in my head"]
  ]

  staging_options = [
    ["yes", "Yes"],
    ["no",  "No"],
    ["na",  "Not applicable"]
  ]

  exact_change_options = [
    ["yes",    "Yes"],
    ["mostly", "Mostly"],
    ["no",     "Not really"]
  ]

  maintenance_options = [
    ["proper", "Yes — proper maintenance window"],
    ["short",  "Sort of — I have a few minutes"],
    ["none",   "No — users are currently using it"]
  ]

  monitoring_options = [
    ["good", "Excellent — I will know immediately if something breaks"],
    ["basic", "Basic — probably enough"],
    ["none", "We will find out when someone complains"]
  ]

  console_options = [
    ["yes",     "Yes"],
    ["no",      "No"],
    ["unknown", "Probably"]
  ]

  experience_options = [
    ["expert",   "I've done this many times"],
    ["familiar", "I've done something similar"],
    ["new",      "I've never done this before"]
  ]

  peer_review_options = [
    ["yes", "Yes"],
    ["no",  "No"]
  ]

  change_size_options = [
    ["trivial",   "Trivial"],
    ["small",     "Small"],
    ["moderate",  "Moderate"],
    ["large",     "Large"],
    ["everything", "It touches basically everything"]
  ]

  urgency_options = [
    ["none",      "Not urgent"],
    ["planned",   "Planned"],
    ["soon",      "It would be nice to do it soon"],
    ["emergency", "EMERGENCY"]
  ]

  five_minutes_options = [
    ["no",  "No"],
    ["yes", "Yes"]
  ]

  puts <<~HTML
    <!DOCTYPE html>
    <html lang="en">

    <head>

        <meta charset="utf-8">

        <meta
            name="viewport"
            content="width=device-width, initial-scale=1.0"
        >

        <link
            rel="icon"
            type="image/x-icon"
            href="/images/icons/favicon.ico"
        >

        <link
            rel="icon"
            type="image/png"
            sizes="32x32"
            href="/images/icons/favicon-32x32.png"
        >

        <link
            rel="icon"
            type="image/png"
            sizes="16x16"
            href="/images/icons/favicon-16x16.png"
        >

        <link
            rel="apple-touch-icon"
            sizes="180x180"
            href="/images/icons/apple-touch-icon.png"
        >

        <link
            rel="manifest"
            href="/images/icons/site.webmanifest"
        >

        <link
            rel="stylesheet"
            href="/css/start.css"
        >

        <title>START Assessment</title>

    </head>

    <body>

    <div class="container">

        <h1>START</h1>

        <div class="subtitle">
            Short-Term Assessment of Risk and Treatability
        </div>

        <p class="description">
            A highly sophisticated assessment system for determining
            whether the thing you are about to do is actually a good idea.
        </p>

        <form method="post" action="start.rb">

            <input
                type="hidden"
                name="submitted"
                value="1"
            >

            <fieldset>

                <legend>1. Proposed operation</legend>

                <label for="activity">
                    What are you planning to do?
                </label>

                <textarea
                    id="activity"
                    name="activity"
                    rows="4"
                    autofocus
                    placeholder="e.g. upgrade the production server"
                ></textarea>

            </fieldset>


            <fieldset>

                <legend>2. Environment</legend>

                <label for="environment">
                    Where are you planning to do it?
                </label>

                #{select_field("environment", "environment", environment_options)}

            </fieldset>


            <fieldset>

                <legend>3. Backup</legend>

                <label for="backup">
                    What is the current backup situation?
                </label>

                #{select_field("backup", "backup", backup_options)}

            </fieldset>


            <fieldset>

                <legend>4. Rollback</legend>

                <label for="rollback">
                    Which rollback procedure exists?
                </label>

                #{select_field("rollback", "rollback", rollback_options)}

            </fieldset>


            <fieldset>

                <legend>5. Operator condition</legend>

                <label for="sleep">
                    How much sleep have you had?
                </label>

                #{select_field("sleep", "sleep", sleep_options)}

                <label for="coffee">
                    How many cups of coffee have you had?
                </label>

                #{select_field("coffee", "coffee", coffee_options)}

            </fieldset>


            <fieldset>

                <legend>6. Documentation</legend>

                <label for="documentation">
                    How sufficient is the documentation?
                </label>

                #{select_field("documentation", "documentation", documentation_options)}

            </fieldset>


            <fieldset>

                <legend>7. Testing</legend>

                <label for="staging">
                    Has this been tested outside production?
                </label>

                #{select_field("staging", "staging", staging_options)}

                <label for="exact_change">
                    Do you know exactly what the change will do?
                </label>

                #{select_field("exact_change", "exact_change", exact_change_options)}

            </fieldset>


            <fieldset>

                <legend>8. Operational safeguards</legend>

                <label for="maintenance">
                    Is there a maintenance window?
                </label>

                #{select_field("maintenance", "maintenance", maintenance_options)}

                <label for="monitoring">
                    How good is the monitoring?
                </label>

                #{select_field("monitoring", "monitoring", monitoring_options)}

                <label for="console">
                    If remote access dies, do you have console access?
                </label>

                #{select_field("console", "console", console_options)}

            </fieldset>


            <fieldset>

                <legend>9. Human factors</legend>

                <label for="experience">
                    How familiar are you with this operation?
                </label>

                #{select_field("experience", "experience", experience_options)}

                <label for="peer_review">
                    Has another human looked at the plan?
                </label>

                #{select_field("peer_review", "peer_review", peer_review_options)}

            </fieldset>


            <fieldset>

                <legend>10. Nature of the change</legend>

                <label for="change_size">
                    How big is the change?
                </label>

                #{select_field("change_size", "change_size", change_size_options)}

                <label for="urgency">
                    How urgent is this?
                </label>

                #{select_field("urgency", "urgency", urgency_options)}

            </fieldset>


            <fieldset>

                <legend>11. The questions that matter</legend>

                <label for="five_minutes">
                    Have you already said "it'll only take five minutes"?
                </label>

                #{select_field("five_minutes", "five_minutes", five_minutes_options)}

            </fieldset>


            <div class="form-actions">

                <button type="submit">
                    Conduct Assessment
                </button>

                <button
                    type="reset"
                    class="secondary"
                >
                    Clear
                </button>

            </div>

        </form>

        <footer>
          <p>
            The Short-Term Assessment of Risk and Treatability (START) is a concise clinical guide for the dynamic assessment of short-term (i.e., weeks to months) risk for violence (to self and others) and treatability.
            This implementation is not a substitute for a professional
            clinical assessment, which should be obvious.
          </p>
        </footer>

    </div>

    </body>
    </html>
  HTML

  exit
end

# ----------------------------------------------------------------------------
# Validate the submitted activity
# ----------------------------------------------------------------------------

v["activity"] = v["activity"].strip

if v["activity"].empty?

  html_header(cgi)

  puts <<~HTML
    <!DOCTYPE html>
    <html lang="en">

    <head>

        <meta charset="utf-8">

        <link
            rel="stylesheet"
            href="/css/start.css"
        >

        <title>START Assessment</title>

    </head>

    <body>

    <div class="container">

        <h1>START</h1>

        <div class="assessment">

            <div class="warning">
                You forgot to tell the assessment system
                what terrible idea you are considering.
            </div>

            <a class="button" href="start.rb">
                Try Again
            </a>

        </div>

    </div>

    </body>
    </html>
  HTML

  exit
end

# ----------------------------------------------------------------------------
# Calculate risk
# ----------------------------------------------------------------------------

risk = 0
treatability = 20

strengths = []
vulnerabilities = []

# ----------------------------------------------------------------------------
# Environment
# ----------------------------------------------------------------------------

case v["environment"]

when "production"

  risk += 25
  vulnerabilities << "Production environment"

when "staging"

  risk += 8
  strengths << "Change is not being made in production"

else

  strengths << "Development environment"
  treatability += 5

end

# ----------------------------------------------------------------------------
# Backup
# ----------------------------------------------------------------------------

case v["backup"]

when "verified"

  risk -= 20
  treatability += 20
  strengths << "Verified restorable backup"

when "exists"

  risk -= 5
  treatability += 8
  strengths << "Backup exists"
  vulnerabilities << "Backup restore has never been tested"

when "none"

  risk += 25
  vulnerabilities << "No backup"

else

  risk += 15
  vulnerabilities << "Backup status is based on optimism"

end

# ----------------------------------------------------------------------------
# Rollback
# ----------------------------------------------------------------------------

case v["rollback"]

when "tested_auto"

  risk -= 18
  treatability += 20
  strengths << "Tested automated rollback"

when "tested_manual"

  risk -= 12
  treatability += 16
  strengths << "Tested manual rollback"

when "documented"

  risk += 3
  treatability += 10
  strengths << "Documented rollback procedure"
  vulnerabilities << "Rollback has not been tested"

when "known"

  risk += 12
  treatability += 3
  vulnerabilities << "Rollback procedure exists mainly in operator memory"

else

  risk += 25
  vulnerabilities << "No rollback procedure"

end

# ----------------------------------------------------------------------------
# Sleep
# ----------------------------------------------------------------------------

case v["sleep"]

when "7plus"

  risk -= 8
  strengths << "Operator has slept"

when "5to7"

  strengths << "Operator has had a reasonable amount of sleep"

when "3to5"

  risk += 10
  vulnerabilities << "Operator is running on reduced sleep"

when "under3"

  risk += 20
  vulnerabilities << "Operator has had insufficient sleep"

else

  risk += 30
  vulnerabilities << "Operator appears to have abandoned sleep"

end

# ----------------------------------------------------------------------------
# Documentation
# ----------------------------------------------------------------------------

case v["documentation"]

when "excellent"

  risk -= 8
  treatability += 8
  strengths << "Excellent documentation"

when "good"

  risk -= 5
  treatability += 5
  strengths << "Good documentation"

when "adequate"

  strengths << "Adequate documentation"

when "poor"

  risk += 8
  vulnerabilities << "Poor documentation"

else

  risk += 15
  vulnerabilities << "Documentation exists exclusively in human memory"

end

# ----------------------------------------------------------------------------
# Staging
# ----------------------------------------------------------------------------

case v["staging"]

when "yes"

  risk -= 10
  treatability += 12
  strengths << "Change has been tested outside production"

when "no"

  risk += 12
  vulnerabilities << "Change has not been tested outside production"

end

# ----------------------------------------------------------------------------
# Exact understanding
# ----------------------------------------------------------------------------

case v["exact_change"]

when "yes"

  risk -= 5
  treatability += 5
  strengths << "Operator understands the proposed change"

when "mostly"

  risk += 5
  vulnerabilities << "Operator understands most of the proposed change"

else

  risk += 15
  vulnerabilities << "Operator does not fully understand the proposed change"

end

# ----------------------------------------------------------------------------
# Maintenance window
# ----------------------------------------------------------------------------

case v["maintenance"]

when "proper"

  risk -= 8
  treatability += 8
  strengths << "Proper maintenance window"

when "short"

  risk += 3
  vulnerabilities << "Maintenance window is suspiciously short"

else

  risk += 15
  vulnerabilities << "Users are currently using the system"

end

# ----------------------------------------------------------------------------
# Monitoring
# ----------------------------------------------------------------------------

case v["monitoring"]

when "good"

  risk -= 5
  treatability += 8
  strengths << "Good monitoring"

when "basic"

  strengths << "Basic monitoring"

else

  risk += 12
  vulnerabilities << "Problems will probably be reported by users"

end

# ----------------------------------------------------------------------------
# Console
# ----------------------------------------------------------------------------

case v["console"]

when "yes"

  treatability += 8
  strengths << "Console access available"

when "no"

  risk += 8
  vulnerabilities << "No console access if remote access fails"

else

  risk += 4
  vulnerabilities << "Console access is theoretical"

end

# ----------------------------------------------------------------------------
# Experience
# ----------------------------------------------------------------------------

case v["experience"]

when "expert"

  risk -= 8
  treatability += 5
  strengths << "Experienced operator"

when "familiar"

  strengths << "Operator has relevant experience"

else

  risk += 12
  vulnerabilities << "Operator has never performed this operation before"

end

# ----------------------------------------------------------------------------
# Peer review
# ----------------------------------------------------------------------------

if v["peer_review"] == "yes"

  risk -= 5
  treatability += 5
  strengths << "Another human reviewed the plan"

else

  risk += 5
  vulnerabilities << "No peer review"

end

# ----------------------------------------------------------------------------
# Change size
# ----------------------------------------------------------------------------

case v["change_size"]

when "trivial"

  risk -= 5

when "small"

  risk += 2

when "moderate"

  risk += 8

when "large"

  risk += 15
  vulnerabilities << "Large change"

else

  risk += 25
  vulnerabilities << "Change appears to involve basically everything"

end

# ----------------------------------------------------------------------------
# Urgency
# ----------------------------------------------------------------------------

case v["urgency"]

when "emergency"

  risk += 15
  vulnerabilities << "Emergency status is being invoked"

when "soon"

  risk += 5

end

# ----------------------------------------------------------------------------
# Five minutes
# ----------------------------------------------------------------------------

if v["five_minutes"] == "yes"

  risk += 15
  vulnerabilities << '"It will only take five minutes" has been uttered'

end

# ----------------------------------------------------------------------------
# Friday / questionable hour
# ----------------------------------------------------------------------------

now = Time.now
hour = now.hour
day = now.wday

if day == 5

  risk += 20
  vulnerabilities << "It is Friday"

elsif hour >= 22 || hour < 6

  risk += 10
  vulnerabilities << "It is an objectively questionable hour"

end

# ----------------------------------------------------------------------------
# Coffee
# ----------------------------------------------------------------------------

case v["coffee"]

when "0"

  risk += 5
  vulnerabilities << "No coffee"

when "1"

  strengths << "At least one coffee has been consumed"

when "10plus"

  risk += 10
  vulnerabilities << "Operator has entered the caffeine event horizon"

else

  if v["coffee"].match?(/^\d+$/) && v["coffee"].to_i >= 6

    risk += 3
    vulnerabilities << "Caffeine level is becoming operationally significant"

  end

end

# ----------------------------------------------------------------------------
# Activity keyword analysis
# ----------------------------------------------------------------------------

lower = v["activity"].downcase

if lower.match?(/\bquick(?:ly)?\b/)

  risk += 12
  vulnerabilities << '"quickly" detected'

end

if lower.match?(/\bsmall\b/)

  risk += 8
  vulnerabilities << '"small" detected'

end

if lower.match?(/\btemporary\b/)

  risk += 10
  vulnerabilities << '"temporary" detected'

end

if lower.match?(/\bproduction\b/)

  risk += 10
  vulnerabilities << '"production" detected in the description'

end

if lower.match?(/\breboot\b|\brestart\b/)

  risk += 8
  vulnerabilities << "Restart/reboot detected"

end

# ----------------------------------------------------------------------------
# Clamp scores
# ----------------------------------------------------------------------------

risk = risk.clamp(0, 100)
treatability = treatability.clamp(0, 100)

# ----------------------------------------------------------------------------
# Overall assessment
# ----------------------------------------------------------------------------

verdict = nil
recommendation = nil
confidence = nil

if risk >= 85

  verdict = "ABSOLUTELY NOT."
  recommendation = "Do not make eye contact with the server."
  confidence = 99

elsif risk >= 70

  verdict = "YOU KNOW BETTER."
  recommendation = "Walk away slowly and improve the rollback plan."
  confidence = 96

elsif risk >= 50

  verdict = "PROBABLY NOT."
  recommendation = "Fix the obvious problems before proceeding."
  confidence = 89

elsif risk >= 30

  verdict = "MAYBE."
  recommendation = "Proceed cautiously. Keep a rollback plan nearby."
  confidence = 78

else

  verdict = "GO FOR IT."
  recommendation = "You appear to have done a surprisingly reasonable job."
  confidence = 71

end

# ----------------------------------------------------------------------------
# Treatability overrides
# ----------------------------------------------------------------------------

if risk >= 70 && treatability < 35

  recommendation =
    "Stop. Establish a backup and tested rollback procedure first."

end

if v["backup"] == "none"

  recommendation =
    "Make a backup before doing anything clever."

end

if v["rollback"] == "none"

  recommendation =
    "Invent a rollback procedure before inventing new problems."

end

if v["sleep"] == "none"

  recommendation =
    "Go to bed. The server will still be broken tomorrow."

end

# ----------------------------------------------------------------------------
# Specific risk estimates
# ----------------------------------------------------------------------------

service_risk = risk

service_risk += 10 if v["environment"] == "production"
service_risk += 10 if v["monitoring"] == "none"
service_risk += 10 if v["rollback"] == "none"

service_risk = service_risk.clamp(0, 100)

data_risk = risk

data_risk += 20 if v["backup"] == "none"
data_risk += 10 if v["backup"] == "unknown"

data_risk = data_risk.clamp(0, 100)

operator_risk = risk

operator_risk += 10 if v["sleep"] == "under3"
operator_risk += 20 if v["sleep"] == "none"
operator_risk += 10 if v["experience"] == "new"

operator_risk = operator_risk.clamp(0, 100)

embarrassment_risk = risk

embarrassment_risk += 10 if v["peer_review"] == "no"
embarrassment_risk += 15 if day == 5

embarrassment_risk = embarrassment_risk.clamp(0, 100)

# ----------------------------------------------------------------------------
# Output
# ----------------------------------------------------------------------------

html_header(cgi)

display_activity = html_escape(v["activity"])

service_level = risk_level(service_risk)
data_level = risk_level(data_risk)
operator_level = risk_level(operator_risk)
embarrassment_level = risk_level(embarrassment_risk)

puts <<~HTML
  <!DOCTYPE html>
  <html lang="en">

  <head>

      <meta charset="utf-8">

      <meta
          name="viewport"
          content="width=device-width, initial-scale=1.0"
      >

      <link
          rel="icon"
          type="image/x-icon"
          href="/images/icons/favicon.ico"
      >

      <link
          rel="icon"
          type="image/png"
          sizes="32x32"
          href="/images/icons/favicon-32x32.png"
      >

      <link
          rel="icon"
          type="image/png"
          sizes="16x16"
          href="/images/icons/favicon-16x16.png"
      >

      <link
          rel="apple-touch-icon"
          sizes="180x180"
          href="/images/icons/apple-touch-icon.png"
      >

      <link
          rel="manifest"
          href="/images/icons/site.webmanifest"
      >

      <link
          rel="stylesheet"
          href="/css/start.css"
      >

      <title>START Assessment</title>

  </head>

  <body>

  <div class="container">

      <h1>START</h1>

      <div class="subtitle">
          Short-Term Assessment of Risk and Treatability
      </div>

      <div class="assessment">

          <div class="question">
              Proposed operation:
          </div>

          <div class="activity">
              #{display_activity}
          </div>


          <h2>STRENGTHS</h2>

          <ul>
  HTML

if strengths.empty?

  puts "<li>None identified. This is concerning.</li>"

else

  strengths.each do |item|
    puts "<li>#{html_escape(item)}</li>"
  end

end

puts <<~HTML
          </ul>


          <h2>VULNERABILITIES</h2>

          <ul class="vulnerabilities">
  HTML

if vulnerabilities.empty?

  puts "<li>None identified. Suspicious.</li>"

else

  vulnerabilities.each do |item|
    puts "<li>#{html_escape(item)}</li>"
  end

end

puts <<~HTML
          </ul>


          <h2>SPECIFIC RISK ESTIMATES</h2>

          <div class="risk-grid">

              <div class="risk-card">
                  <span>Service interruption</span>
                  <strong>#{service_risk}%</strong>
                  <small>#{service_level}</small>
              </div>

              <div class="risk-card">
                  <span>Data loss</span>
                  <strong>#{data_risk}%</strong>
                  <small>#{data_level}</small>
              </div>

              <div class="risk-card">
                  <span>Operator error</span>
                  <strong>#{operator_risk}%</strong>
                  <small>#{operator_level}</small>
              </div>

              <div class="risk-card">
                  <span>Explaining this later</span>
                  <strong>#{embarrassment_risk}%</strong>
                  <small>#{embarrassment_level}</small>
              </div>

          </div>


          <h2>TREATABILITY</h2>

          <div class="big-score">
              #{treatability}%
          </div>

          <p class="score-explanation">
              Estimated percentage of this situation that can still be
              made less terrible before proceeding.
          </p>


          <h2>OVERALL RISK</h2>

          <div class="big-score risk-score">
              #{risk}%
          </div>


          <h2>OVERALL ASSESSMENT</h2>

          <div class="verdict">
              #{html_escape(verdict)}
          </div>


          <div class="recommendation">

              <strong>Recommendation:</strong>

              <br>

              #{html_escape(recommendation)}

          </div>


          <div class="confidence">
              Confidence: #{confidence}%
          </div>


          <div class="assessment-footer">

              <a class="button" href="start.rb">
                  Conduct Another Assessment
              </a>

          </div>

      </div>

  </div>

  </body>
  </html>
HTML

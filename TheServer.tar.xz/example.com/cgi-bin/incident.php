<?php

/*
 * ============================================================================
 * INCIDENT
 *
 * Incident Assessment and Report Generator
 *
 * A completely serious incident management system. Probably.
 * ============================================================================
 */

function h($value)
{
    return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8');
}

function selected($actual, $value)
{
    return ($actual === $value) ? ' selected' : '';
}

function risk_level($score)
{
    if ($score >= 80) return 'CRITICAL';
    if ($score >= 60) return 'HIGH';
    if ($score >= 35) return 'MODERATE';
    if ($score >= 15) return 'LOW';
    return 'MINIMAL';
}

$submitted = isset($_POST['submitted']);

if (!$submitted) {
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <link
        rel="stylesheet"
        href="/css/incident.css"
    >

    <title>Incident Assessment</title>

</head>

<body>

<div class="container">

    <h1>INCIDENT</h1>

    <div class="subtitle">
        Incident Assessment and Report Generator
    </div>

    <p class="description">
        A sophisticated system for determining exactly how badly
        everything has gone wrong.
    </p>


    <form method="post" action="incident.php">

        <input
            type="hidden"
            name="submitted"
            value="1"
        >


        <fieldset>

            <legend>1. What happened?</legend>

            <label for="incident">
                Describe the incident.
            </label>

            <textarea
                id="incident"
                name="incident"
                rows="5"
                autofocus
                placeholder="e.g. The production server stopped responding."
            ></textarea>

        </fieldset>


        <fieldset>

            <legend>2. Who noticed?</legend>

            <label for="detected">
                How was the incident detected?
            </label>

            <select id="detected" name="detected">

                <option value="monitoring">
                    Monitoring detected it
                </option>

                <option value="human">
                    A human noticed
                </option>

                <option value="customer">
                    A customer noticed
                </option>

                <option value="manager">
                    Management noticed
                </option>

                <option value="nobody">
                    Nobody noticed yet
                </option>

            </select>

        </fieldset>


        <fieldset>

            <legend>3. How bad is it?</legend>

            <label for="impact">
                Current impact
            </label>

            <select id="impact" name="impact">

                <option value="none">
                    Everything appears fine
                </option>

                <option value="minor">
                    Minor inconvenience
                </option>

                <option value="moderate">
                    Some users are affected
                </option>

                <option value="major">
                    Large number of users affected
                </option>

                <option value="catastrophic">
                    Basically everything is on fire
                </option>

            </select>

        </fieldset>


        <fieldset>

            <legend>4. Backup</legend>

            <label for="backup">
                Is there a backup?
            </label>

            <select id="backup" name="backup">

                <option value="verified">
                    Yes, and it has been successfully restored before
                </option>

                <option value="exists">
                    Yes, presumably
                </option>

                <option value="unknown">
                    Nobody knows
                </option>

                <option value="none">
                    No
                </option>

            </select>

        </fieldset>


        <fieldset>

            <legend>5. Rollback</legend>

            <label for="rollback">
                Can the change be rolled back?
            </label>

            <select id="rollback" name="rollback">

                <option value="tested">
                    Yes, tested and documented
                </option>

                <option value="possible">
                    Probably
                </option>

                <option value="manual">
                    Yes, but it involves several commands nobody remembers
                </option>

                <option value="no">
                    No
                </option>

            </select>

        </fieldset>


        <fieldset>

            <legend>6. Root cause</legend>

            <label for="cause">
                What is the current theory?
            </label>

            <select id="cause" name="cause">

                <option value="known">
                    Root cause is known
                </option>

                <option value="likely">
                    We have a pretty good theory
                </option>

                <option value="dns">
                    Probably DNS
                </option>

                <option value="network">
                    Probably the network
                </option>

                <option value="unknown">
                    We have absolutely no idea
                </option>

            </select>

        </fieldset>


        <fieldset>

            <legend>7. Operator behaviour</legend>

            <label for="reboot">
                Has anyone rebooted anything?
            </label>

            <select id="reboot" name="reboot">

                <option value="no">
                    No
                </option>

                <option value="yes">
                    Yes
                </option>

                <option value="multiple">
                    Several things
                </option>

                <option value="everything">
                    We may have rebooted everything
                </option>

            </select>


            <label for="phrase">
                Has anyone said "it shouldn't affect production"?
            </label>

            <select id="phrase" name="phrase">

                <option value="no">
                    No
                </option>

                <option value="yes">
                    Yes
                </option>

            </select>

        </fieldset>


        <fieldset>

            <legend>8. Communication</legend>

            <label for="communication">
                How is communication going?
            </label>

            <select id="communication" name="communication">

                <option value="excellent">
                    Excellent
                </option>

                <option value="adequate">
                    Adequate
                </option>

                <option value="confused">
                    Multiple conflicting explanations
                </option>

                <option value="silent">
                    Everyone has stopped talking
                </option>

            </select>

        </fieldset>


        <fieldset>

            <legend>9. Responsibility</legend>

            <label for="responsibility">
                Has anyone admitted responsibility?
            </label>

            <select id="responsibility" name="responsibility">

                <option value="yes">
                    Yes
                </option>

                <option value="maybe">
                    Someone said "I might have..."
                </option>

                <option value="no">
                    No
                </option>

                <option value="blame">
                    Everyone is blaming everyone else
                </option>

            </select>

        </fieldset>


        <fieldset>

            <legend>10. The important question</legend>

            <label for="coffee">
                How much coffee is currently available?
            </label>

            <select id="coffee" name="coffee">

                <option value="plenty">
                    Plenty
                </option>

                <option value="some">
                    Some
                </option>

                <option value="last">
                    One cup remains
                </option>

                <option value="none">
                    None
                </option>

            </select>

        </fieldset>


        <div class="form-actions">

            <button type="submit">
                Generate Incident Report
            </button>

            <button
                type="reset"
                class="secondary"
            >
                Clear
            </button>

        </div>

    </form>

</div>

</body>
</html>

<?php
    exit;
}


/*
 * ============================================================================
 * Read submitted values
 * ============================================================================
 */

$incident      = trim($_POST['incident'] ?? '');
$detected      = $_POST['detected'] ?? '';
$impact        = $_POST['impact'] ?? '';
$backup        = $_POST['backup'] ?? '';
$rollback      = $_POST['rollback'] ?? '';
$cause         = $_POST['cause'] ?? '';
$reboot        = $_POST['reboot'] ?? '';
$phrase        = $_POST['phrase'] ?? '';
$communication = $_POST['communication'] ?? '';
$responsibility = $_POST['responsibility'] ?? '';
$coffee        = $_POST['coffee'] ?? '';


/*
 * ============================================================================
 * Validate
 * ============================================================================
 */

if ($incident === '') {
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">

    <link
        rel="stylesheet"
        href="/css/incident.css"
    >

    <title>Incident Assessment</title>

</head>

<body>

<div class="container">

    <h1>INCIDENT</h1>

    <div class="assessment">

        <div class="warning">
            An incident cannot be assessed if nobody is willing
            to describe what happened.
        </div>

        <a
            class="button"
            href="incident.php"
        >
            Try Again
        </a>

    </div>

</div>

</body>
</html>
<?php
    exit;
}


/*
 * ============================================================================
 * Calculate severity
 * ============================================================================
 */

$severity = 0;

$strengths = [];
$problems  = [];


/* Impact */

switch ($impact) {

    case 'none':
        $severity += 0;
        $strengths[] = 'No measurable impact detected';
        break;

    case 'minor':
        $severity += 15;
        $problems[] = 'Minor user impact';
        break;

    case 'moderate':
        $severity += 35;
        $problems[] = 'Multiple users are affected';
        break;

    case 'major':
        $severity += 60;
        $problems[] = 'Large-scale user impact';
        break;

    case 'catastrophic':
        $severity += 90;
        $problems[] = 'Everything is basically on fire';
        break;
}


/* Detection */

switch ($detected) {

    case 'monitoring':
        $severity -= 5;
        $strengths[] = 'Monitoring detected the incident';
        break;

    case 'human':
        $severity += 5;
        $problems[] = 'Human detection was required';
        break;

    case 'customer':
        $severity += 15;
        $problems[] = 'Customer detected the incident';
        break;

    case 'manager':
        $severity += 20;
        $problems[] = 'Management detected the incident';
        break;

    case 'nobody':
        $severity += 30;
        $problems[] = 'Nobody has actually detected the problem yet';
        break;
}


/* Backup */

switch ($backup) {

    case 'verified':
        $severity -= 15;
        $strengths[] = 'Verified backup available';
        break;

    case 'exists':
        $severity += 5;
        $strengths[] = 'Backup apparently exists';
        break;

    case 'unknown':
        $severity += 15;
        $problems[] = 'Backup status is unknown';
        break;

    case 'none':
        $severity += 25;
        $problems[] = 'No backup exists';
        break;
}


/* Rollback */

switch ($rollback) {

    case 'tested':
        $severity -= 15;
        $strengths[] = 'Tested rollback available';
        break;

    case 'possible':
        $severity += 5;
        $problems[] = 'Rollback is theoretically possible';
        break;

    case 'manual':
        $severity += 12;
        $problems[] = 'Rollback depends on human memory';
        break;

    case 'no':
        $severity += 25;
        $problems[] = 'There is no rollback procedure';
        break;
}


/* Root cause */

switch ($cause) {

    case 'known':
        $severity -= 10;
        $strengths[] = 'Root cause is known';
        break;

    case 'likely':
        $severity += 5;
        $problems[] = 'Root cause is only approximately known';
        break;

    case 'dns':
        $severity += 8;
        $problems[] = 'Someone blamed DNS';
        break;

    case 'network':
        $severity += 8;
        $problems[] = 'Someone blamed the network';
        break;

    case 'unknown':
        $severity += 20;
        $problems[] = 'Nobody knows the root cause';
        break;
}


/* Reboots */

if ($reboot === 'yes') {

    $severity += 5;
    $problems[] = 'A reboot has occurred';

}

elseif ($reboot === 'multiple') {

    $severity += 15;
    $problems[] = 'Multiple reboots have occurred';

}

elseif ($reboot === 'everything') {

    $severity += 25;
    $problems[] = 'Someone may have rebooted everything';

}


/* Famous phrase */

if ($phrase === 'yes') {

    $severity += 15;

    $problems[] =
        '"It shouldn\'t affect production" was said';

}


/* Communication */

switch ($communication) {

    case 'excellent':
        $severity -= 5;
        $strengths[] = 'Communication remains functional';
        break;

    case 'adequate':
        $strengths[] = 'Communication is adequate';
        break;

    case 'confused':
        $severity += 10;
        $problems[] = 'Multiple conflicting explanations exist';
        break;

    case 'silent':
        $severity += 20;
        $problems[] = 'Everyone has stopped talking';
        break;
}


/* Responsibility */

switch ($responsibility) {

    case 'yes':
        $strengths[] = 'Someone has accepted responsibility';
        break;

    case 'maybe':
        $severity += 5;
        $problems[] = 'Responsibility is being expressed cautiously';
        break;

    case 'no':
        $severity += 5;
        $problems[] = 'Nobody has accepted responsibility';
        break;

    case 'blame':
        $severity += 15;
        $problems[] = 'Everyone is blaming everyone else';
        break;
}


/* Coffee */

switch ($coffee) {

    case 'plenty':
        $strengths[] = 'Adequate coffee reserves';
        break;

    case 'some':
        $strengths[] = 'Coffee remains available';
        break;

    case 'last':
        $severity += 5;
        $problems[] = 'Only one cup of coffee remains';
        break;

    case 'none':
        $severity += 15;
        $problems[] = 'There is no coffee';
        break;
}


/*
 * ============================================================================
 * Clamp
 * ============================================================================
 */

$severity = max(0, min(100, $severity));

$level = risk_level($severity);


/*
 * ============================================================================
 * Determine verdict
 * ============================================================================
 */

if ($severity >= 80) {

    $verdict = 'THIS IS NOW AN INCIDENT.';

    $recommendation =
        'Stop making changes. Establish command, preserve evidence, and breathe.';

}

elseif ($severity >= 60) {

    $verdict = 'THIS HAS BECOME SERIOUS.';

    $recommendation =
        'Stabilise the system before attempting anything clever.';

}

elseif ($severity >= 35) {

    $verdict = 'SOMETHING HAS DEFINITELY GONE WRONG.';

    $recommendation =
        'Investigate methodically. Resist the urge to reboot everything.';

}

elseif ($severity >= 15) {

    $verdict = 'MINOR INCIDENT. PROBABLY.';

    $recommendation =
        'Document what happened before somebody accidentally fixes it.';

}

else {

    $verdict = 'NO SIGNIFICANT INCIDENT DETECTED.';

    $recommendation =
        'Continue monitoring and try not to create one.';

}


/*
 * ============================================================================
 * Special recommendations
 * ============================================================================
 */

if ($backup === 'none') {

    $recommendation =
        'Do not make things worse. There is no backup.';

}

if ($coffee === 'none') {

    $recommendation =
        'Acquire coffee before making further operational decisions.';

}

if ($reboot === 'everything') {

    $recommendation =
        'Stop rebooting things. Seriously.';

}

if ($communication === 'silent') {

    $recommendation =
        'Someone needs to start talking before this becomes a mystery.';

}


/*
 * ============================================================================
 * Output
 * ============================================================================
 */

?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <link
        rel="icon"
        type="image/x-icon"
        href="/images/icons/favicon.ico"
    >

    <link
        rel="icon"
        type="image/png"
        sizes="32x32"
        href="/images/icons/favicon-32x32.png"
    >

    <link
        rel="icon"
        type="image/png"
        sizes="16x16"
        href="/images/icons/favicon-16x16.png"
    >

    <link
        rel="apple-touch-icon"
        sizes="180x180"
        href="/images/icons/apple-touch-icon.png"
    >

    <link
        rel="manifest"
        href="/images/icons/site.webmanifest"
    >

    <link
        rel="stylesheet"
        href="/css/incident.css"
    >

    <title>Incident Report</title>

</head>

<body>

<div class="container">

    <h1>INCIDENT</h1>

    <div class="subtitle">
        Incident Assessment and Report
    </div>


    <div class="assessment">


        <div class="question">
            Reported incident
        </div>

        <div class="activity">
            <?= h($incident) ?>
        </div>


        <h2>SEVERITY</h2>

        <div class="big-score">
            <?= $severity ?>%
        </div>

        <div class="risk-level">
            <?= h($level) ?>
        </div>


        <h2>WHAT WE KNOW</h2>

        <ul>

<?php

if (count($strengths) === 0) {

    echo '<li>Very little. This is not encouraging.</li>';

}

foreach ($strengths as $item) {

    echo '<li>', h($item), '</li>';

}

?>

        </ul>


        <h2>WHAT CONCERNS US</h2>

        <ul class="vulnerabilities">

<?php

if (count($problems) === 0) {

    echo '<li>No significant concerns identified.</li>';

}

foreach ($problems as $item) {

    echo '<li>', h($item), '</li>';

}

?>

        </ul>


        <h2>ASSESSMENT</h2>

        <div class="verdict">
            <?= h($verdict) ?>
        </div>


        <div class="recommendation">

            <strong>Recommendation:</strong>

            <br>

            <?= h($recommendation) ?>

        </div>


        <h2>INCIDENT STATUS</h2>

        <div class="status-grid">

            <div class="status-card">
                <span>Severity</span>
                <strong><?= $severity ?>%</strong>
            </div>

            <div class="status-card">
                <span>Classification</span>
                <strong><?= h($level) ?></strong>
            </div>

            <div class="status-card">
                <span>Root Cause</span>
                <strong><?= h(
                    $cause === 'known'
                        ? 'Known'
                        : 'Unconfirmed'
                ) ?></strong>
            </div>

            <div class="status-card">
                <span>Backup</span>
                <strong><?= h(
                    $backup === 'verified'
                        ? 'Verified'
                        : 'Questionable'
                ) ?></strong>
            </div>

        </div>


        <div class="assessment-footer">

            <a
                class="button"
                href="incident.php"
            >
                Assess Another Incident
            </a>

        </div>

    </div>

</div>

</body>
</html>

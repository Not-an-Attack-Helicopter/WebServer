#!/usr/bin/env python3

import os
from urllib.parse import parse_qs
from html import escape


# ---------------------------------------------------------------------------
# Get the current button-press count.
#
# We keep it in the URL/form rather than a server-side file, so the script
# needs no special permissions and works safely with multiple users.
# ---------------------------------------------------------------------------

query = os.environ.get("QUERY_STRING", "")
params = parse_qs(query)

try:
    count = int(params.get("count", ["0"])[0])
except (ValueError, TypeError):
    count = 0

# Don't allow silly/negative values.
count = max(0, count)


# ---------------------------------------------------------------------------
# Messages
# ---------------------------------------------------------------------------

if count == 0:
    title = "The Button"
    message = "Go ahead. You know you want to."

elif count == 1:
    title = "I warned you."
    message = "You pressed the button."

elif count == 2:
    title = "Again?"
    message = "You have pressed the button twice."

elif count == 3:
    title = "Seriously?"
    message = "There are literally millions of websites on the Internet."

elif count == 4:
    title = "This is becoming a problem."
    message = "Please stop pressing the button."

elif count == 5:
    title = "Fine."
    message = "Press it again. See if I care."

elif count == 6:
    title = "I care."
    message = "I very much care."

elif count == 7:
    title = "STOP."
    message = "This is your last warning."

elif count == 8:
    title = "You were warned."
    message = "The button has filed a complaint with the server."

elif count == 9:
    title = "Administrative action"
    message = "Your button privileges are being reviewed."

elif count == 10:
    title = "INCIDENT REPORT"
    message = "The situation has been escalated to Level 2 Button Management."

elif count < 20:
    title = "Please seek assistance."
    message = (
        f"You have pressed this button {count} times. "
        "There is no prize."
    )

elif count < 50:
    title = "This is impressive."
    message = (
        f"{count} presses. "
        "I have stopped judging you and started documenting you."
    )

else:
    title = "You win."
    message = (
        f"{count} presses. "
        "Nobody knows what you were expecting."
    )


# ---------------------------------------------------------------------------
# Output HTML
# ---------------------------------------------------------------------------

print("Content-Type: text/html; charset=UTF-8")
print()

print("""<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <link
        rel="icon"
        type="image/x-icon"
        href="/images/icons/favicon.ico"
    >

    <link
        rel="icon"
        type="image/png"
        sizes="32x32"
        href="/images/icons/favicon-32x32.png"
    >

    <link
        rel="icon"
        type="image/png"
        sizes="16x16"
        href="/images/icons/favicon-16x16.png"
    >

    <link
        rel="apple-touch-icon"
        sizes="180x180"
        href="/images/icons/apple-touch-icon.png"
    >

    <link
        rel="manifest"
        href="/images/icons/site.webmanifest"
    >

    <link
        rel="stylesheet"
        href="/css/the_button.css"
    >

    <title>The Button</title>

</head>

<body>

<div class="container">

""")

print(f"<h1>{escape(title)}</h1>")

print(f'<div class="message">{escape(message)}</div>')

print(f'<div class="count">Button presses: {count}</div>')

print("""
<form method="get">

    <input
        type="hidden"
        name="count"
        value="
""")

print(count + 1)

print("""">

    <button type="submit">
        DO NOT<br>PRESS
    </button>

</form>

<div class="warning">
    Seriously. Don't press it.
</div>

</div>

</body>
</html>
""")

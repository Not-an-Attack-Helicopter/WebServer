#!/usr/bin/env perl

#
# A simple Perl CGI Sudoku solver.
#
# Based on the original script by Pedro / lamehacks.net
#

use strict;
use warnings;

use CGI qw(escapeHTML);

my $cgi = CGI->new;


# ============================================================================
# MAIN PROGRAM
# ============================================================================

# No puzzle submitted: show an empty form.
if (!defined($cgi->param('solve')) &&
    !defined($cgi->param('puzzle'))) {

    show_html_form();
    exit;
}


# ============================================================================
# Get the puzzle.
#
# There are two possible input methods:
#
#   1. The normal 9x9 HTML table:
#        c11, c12, ... c99
#
#   2. The raw puzzle field:
#        puzzle
#
# IMPORTANT:
#
# Solved cells are rendered as "disabled" inputs. Disabled inputs are NOT
# submitted by the browser. Therefore, when solving a second time, Perl
# receives only the original editable clues.
# ============================================================================

my $puzzleraw;
my $input_error;


if (defined($cgi->param('puzzle'))) {

    # Raw puzzle input.
    $puzzleraw = $cgi->param('puzzle');

}
else {

    # 9x9 HTML table input.
    ($puzzleraw, $input_error) =
        process_input_from_html_form($cgi);
}


# ============================================================================
# Invalid cell input.
# ============================================================================

if ($input_error) {

    show_html_form(
        error => $input_error
    );

    exit;
}


# ============================================================================
# Clean up raw puzzle.
# ============================================================================

# Dots can be used for blanks.
$puzzleraw =~ s/\./0/g;

# Vertical bars can be used as visual separators.
$puzzleraw =~ s/\|//g;

# Remove leading/trailing whitespace.
$puzzleraw =~ s/^\s+//;
$puzzleraw =~ s/\s+$//;


# ============================================================================
# Validate the puzzle format.
# ============================================================================

if ($puzzleraw !~ /^\d{81}$/) {

    show_html_form(
        error =>
            "Invalid puzzle. Please enter exactly 81 digits, "
          . "using 0 or . for empty cells."
    );

    exit;
}


# ============================================================================
# Put the puzzle into our array format.
# ============================================================================

my @puzzle = put_into_array($puzzleraw);


# ============================================================================
# Check for conflicting numbers.
#
# We deliberately do NOT throw the puzzle away if conflicts exist.
# Instead, we keep @puzzle and send it back to the HTML form.
# ============================================================================

my @conflicts = find_conflicts(@puzzle);

if (@conflicts) {

    show_html_form(
        puzzle    => \@puzzle,
        conflicts => \@conflicts,
        error     =>
            "The puzzle contains conflicting numbers. "
          . "The conflicting cells are marked in red."
    );

    exit;
}


# ============================================================================
# Solve the puzzle.
# ============================================================================

my @solution = solve(@puzzle);


# ============================================================================
# No solution exists.
# ============================================================================

if (!@solution) {

    show_html_form(
        puzzle => \@puzzle,
        error  =>
            "This puzzle has no solution."
    );

    exit;
}


# ============================================================================
# Display solved puzzle.
# ============================================================================

show_html_form(
    puzzle => \@puzzle,
    solved => \@solution
);

exit;


# ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# S U B R O U T I N E S
# ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++


# ============================================================================
# Sudoku solver
# ============================================================================
#
# Returns the solved puzzle as an array.
# Returns an empty list if the puzzle cannot be solved.
# ============================================================================

sub solve {

    my @puzzle = @_;

    # Nothing left to solve.
    if (!have_empty_cells(@puzzle)) {
        return @puzzle;
    }


    # Find first empty cell.
    my $empty_cell_position =
        find_first_empty_cell(@puzzle);

    return () if !$empty_cell_position;


    # Get possible values.
    my @possibilities =
        get_possibilities(
            $empty_cell_position,
            @puzzle
        );

    return () if !@possibilities;


    # Try every possibility.
    for my $possible_value (@possibilities) {

        my @candidate = @puzzle;

        $candidate[$empty_cell_position] =
            $possible_value;


        my @result =
            solve(@candidate);


        # Found a solution.
        if (@result) {
            return @result;
        }
    }


    # No solution.
    return ();
}


# ============================================================================
# Convert an 81-character puzzle into our array format.
#
# Cell positions are:
#
#     11 12 13 ... 19
#     21 22 23 ... 29
#     ...
#     91 92 93 ... 99
#
# The tens digit is the row.
# The units digit is the column.
# ============================================================================

sub put_into_array {

    my ($raw) = @_;

    my @characters =
        split //, $raw;

    my @puzzle;

    my $position = 11;


    for my $character (@characters) {

        # Skip positions 20, 30, 40, etc.
        if ($position % 10 == 0) {
            $position++;
        }

        $puzzle[$position] =
            $character;

        $position++;
    }


    return @puzzle;
}


# ============================================================================
# Find all cells involved in Sudoku conflicts.
#
# Both cells are marked when two equal numbers occupy:
#
#   - the same row
#   - the same column
#   - the same 3x3 box
# ============================================================================

sub find_conflicts {

    my @puzzle = @_;

    my %conflicts;


    for my $row (1 .. 9) {

        for my $column (1 .. 9) {

            my $position =
                $row * 10 + $column;

            my $value =
                $puzzle[$position];

            next if !defined($value);
            next if $value == 0;


            my @neighbours =
                get_neighbours($position);


            for my $neighbour (@neighbours) {

                my $neighbour_value =
                    $puzzle[$neighbour];

                next if !defined($neighbour_value);
                next if $neighbour_value == 0;


                if ($value == $neighbour_value) {

                    $conflicts{$position}  = 1;
                    $conflicts{$neighbour} = 1;
                }
            }
        }
    }


    return keys %conflicts;
}


# ============================================================================
# Determine whether there are empty cells.
# ============================================================================

sub have_empty_cells {

    my @puzzle = @_;


    for my $row (1 .. 9) {

        for my $column (1 .. 9) {

            my $position =
                $row * 10 + $column;


            if (defined($puzzle[$position]) &&
                $puzzle[$position] == 0) {

                return 1;
            }
        }
    }


    return 0;
}


# ============================================================================
# Find the first empty cell.
# ============================================================================

sub find_first_empty_cell {

    my @puzzle = @_;


    for my $row (1 .. 9) {

        for my $column (1 .. 9) {

            my $position =
                $row * 10 + $column;


            if (defined($puzzle[$position]) &&
                $puzzle[$position] == 0) {

                return $position;
            }
        }
    }


    return 0;
}


# ============================================================================
# Get all cells sharing a row, column or 3x3 box with the given cell.
# ============================================================================

sub get_neighbours {

    my ($cell_position) = @_;


    my $column =
        $cell_position % 10;

    my $row =
        int($cell_position / 10);


    my %seen;

    my @neighbours;


    # ------------------------------------------------------------------------
    # Same row.
    # ------------------------------------------------------------------------

    for my $c (1 .. 9) {

        my $position =
            $row * 10 + $c;

        next if $position == $cell_position;

        if (!$seen{$position}++) {
            push @neighbours, $position;
        }
    }


    # ------------------------------------------------------------------------
    # Same column.
    # ------------------------------------------------------------------------

    for my $r (1 .. 9) {

        my $position =
            $r * 10 + $column;

        next if $position == $cell_position;

        if (!$seen{$position}++) {
            push @neighbours, $position;
        }
    }


    # ------------------------------------------------------------------------
    # Same 3x3 box.
    # ------------------------------------------------------------------------

    my $box_first_row =
        int(($row - 1) / 3) * 3 + 1;

    my $box_first_column =
        int(($column - 1) / 3) * 3 + 1;


    for my $r (
        $box_first_row .. $box_first_row + 2
    ) {

        for my $c (
            $box_first_column .. $box_first_column + 2
        ) {

            my $position =
                $r * 10 + $c;

            next if $position == $cell_position;

            if (!$seen{$position}++) {
                push @neighbours, $position;
            }
        }
    }


    return @neighbours;
}


# ============================================================================
# Get possible values for a cell.
# ============================================================================

sub get_possibilities {

    my ($cell_position, @puzzle) = @_;

    my %used_values;


    my @neighbours =
        get_neighbours($cell_position);


    for my $position (@neighbours) {

        my $value =
            $puzzle[$position];

        next if !defined($value);
        next if $value == 0;

        $used_values{$value} = 1;
    }


    my @possibilities;


    for my $value (1 .. 9) {

        if (!$used_values{$value}) {

            push @possibilities, $value;
        }
    }


    return @possibilities;
}


# ============================================================================
# Process the normal HTML table input.
#
# Only c11 through c99 are read.
#
# IMPORTANT:
#
# Solver-generated cells use "disabled" inputs, and disabled HTML inputs
# are not submitted by the browser.
#
# Consequently, this function receives ONLY the original clues.
# ============================================================================

sub process_input_from_html_form {

    my ($mycgi) = @_;

    my $puzzleraw = '';


    for my $row (1 .. 9) {

        for my $column (1 .. 9) {

            my $name =
                "c$row$column";


            my $value =
                $mycgi->param($name);


            $value = ''
                if !defined($value);


            # Empty or exactly one digit.
            if ($value !~ /^\d?$/) {

                return (
                    undef,
                    "Invalid input in cell "
                    . "$row,$column."
                );
            }


            if ($value eq '') {

                $puzzleraw .= '0';

            }
            else {

                $puzzleraw .= $value;
            }
        }
    }


    return ($puzzleraw, undef);
}


# ============================================================================
# Generate the Sudoku table.
#
# ORIGINAL CLUE
#     black
#     editable
#     submitted as cXY
#
# SOLVED VALUE
#     blue
#     disabled
#     NOT submitted
#
# CONFLICT
#     pale red background
#     red number
# ============================================================================

sub sudoku_table {

    my ($puzzle, $solution, $conflicts) = @_;

    $conflicts ||= [];


    my %conflict_cells =
        map { $_ => 1 } @$conflicts;


    my $html = <<'HTML';
<table class="sudoku">
    <tbody>
HTML


    for my $row (1 .. 9) {

        $html .= "        <tr>\n";


        for my $column (1 .. 9) {

            my $position =
                $row * 10 + $column;


            # ----------------------------------------------------------------
            # Original puzzle value.
            # ----------------------------------------------------------------

            my $original_value =
                defined($puzzle->[$position])
                ? $puzzle->[$position]
                : 0;


            # ----------------------------------------------------------------
            # Determine cell class.
            # ----------------------------------------------------------------

            my $class;


            if ($conflict_cells{$position}) {

                $class = 'conflict';

            }
            elsif ($solution &&
                   $original_value == 0) {

                $class = 'solved';

            }
            else {

                $class = 'given';
            }


            # ----------------------------------------------------------------
            # ORIGINAL CLUE
            # ----------------------------------------------------------------

            if ($original_value != 0) {

                $html .= qq{
            <td class="$class">
                <input
                    type="text"
                    maxlength="1"
                    size="1"
                    name="c${row}${column}"
                    value="@{[escapeHTML($original_value)]}"
                    inputmode="numeric"
                    autocomplete="off"
                />
            </td>
};

            }


            # ----------------------------------------------------------------
            # EMPTY CELL / SOLVED CELL
            # ----------------------------------------------------------------

            else {

                my $solution_value = '';


                if ($solution &&
                    defined($solution->[$position]) &&
                    $solution->[$position] != 0) {

                    $solution_value =
                        $solution->[$position];
                }


                # ------------------------------------------------------------
                # A solver-generated value.
                #
                # "disabled" is intentional:
                #
                # Disabled controls are NOT submitted with the form.
                # Therefore a previous solution can never become a new clue.
                # ------------------------------------------------------------

                if ($solution_value ne '') {

                    $html .= qq{
            <td class="solved">
                <input
                    type="text"
                    maxlength="1"
                    size="1"
                    value="@{[escapeHTML($solution_value)]}"
                    disabled
                />
            </td>
};

                }


                # ------------------------------------------------------------
                # Still empty.
                # ------------------------------------------------------------

                else {

                    $html .= qq{
            <td class="given">
                <input
                    type="text"
                    maxlength="1"
                    size="1"
                    name="c${row}${column}"
                    value=""
                    inputmode="numeric"
                    autocomplete="off"
                />
            </td>
};
                }
            }
        }


        $html .= "        </tr>\n";
    }


    $html .= <<'HTML';
    </tbody>
</table>
HTML


    return $html;
}


# ============================================================================
# Show the HTML page.
# ============================================================================

sub show_html_form {

    my %args = @_;


    my $puzzle =
        $args{puzzle};


    my $solution =
        $args{solved};


    my $error =
        $args{error};


    my $conflicts =
        $args{conflicts};


    # ------------------------------------------------------------------------
    # HTTP header.
    # ------------------------------------------------------------------------

    print $cgi->header(
        -type    => 'text/html',
        -charset => 'UTF-8'
    );


    # ------------------------------------------------------------------------
    # Page header.
    # ------------------------------------------------------------------------

    print <<'HTML';
<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="utf-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <link
        rel="icon"
        type="image/x-icon"
        href="/images/icons/favicon.ico"
    >

    <link
        rel="icon"
        type="image/png"
        sizes="32x32"
        href="/images/icons/favicon-32x32.png"
    >

    <link
        rel="icon"
        type="image/png"
        sizes="16x16"
        href="/images/icons/favicon-16x16.png"
    >

    <link
        rel="apple-touch-icon"
        sizes="180x180"
        href="/images/icons/apple-touch-icon.png"
    >

    <link
        rel="manifest"
        href="/images/icons/site.webmanifest"
    >

    <link
        rel="stylesheet"
        href="/css/sudoku.css"
    >

    <title>Sudoku Solver</title>

</head>


<body>

<h1>Sudoku Solver</h1>

<h4>courtesy of lamehacks.net</h4>

<a href="/">Back to example.com</a>

<p>
    Fill in your sudoku puzzle and click 'Solve me!'
</p>

HTML


    # ------------------------------------------------------------------------
    # Error message.
    # ------------------------------------------------------------------------

    if ($error) {

        print qq{
<div class="message error">
    @{[escapeHTML($error)]}
</div>
};

    }


    # ------------------------------------------------------------------------
    # Success message.
    # ------------------------------------------------------------------------

    elsif ($solution) {

        print <<'HTML';
<div class="message success">
    Puzzle solved!
</div>

<div class="legend">
    Black numbers are the original clues.
    <span class="blue">Blue numbers</span>
    were added by the solver.
</div>
HTML

    }


    # ------------------------------------------------------------------------
    # Sudoku form.
    # ------------------------------------------------------------------------

    print <<'HTML';

<form action="sudoku.cgi" method="get">

HTML


    print sudoku_table(
        $puzzle || [],
        $solution,
        $conflicts
    );


    print <<'HTML';

    <div class="buttons">

        <input
            type="submit"
            value="Solve me!"
            name="solve"
        >

        <!--
            Clear deliberately reloads the CGI with no parameters.
            This gives us a completely fresh Sudoku board.
        -->

        <button
            type="button"
            onclick="window.location.href='sudoku.cgi';"
        >
            Clear
        </button>

    </div>

</form>


<hr>


<p>
    If you prefer you can insert the puzzle in a raw format:
</p>


<form action="sudoku.cgi" method="get">

    <input
        type="text"
        name="puzzle"
        value=""
        class="raw"
        size="75"
    >

    <br><br>

    <input
        type="submit"
        value="Solve me!"
        name="solveraw"
    >

</form>


<br>


<p>
    <strong>Usage:</strong><br>
    Use zeros or dots for blanks.
    You can use vertical bars for visual aid as they will be ignored.
</p>


<p>
    <strong>Examples:</strong>
</p>


<div class="examples">

<p>
.14.6.3..62...4..9.8..5.6...6.2....3.7..1..5.5....9.6...6.2..3.1..5...92..7.9.41.
</p>


<p>
|.14.6.3..|62...4..9|.8..5.6..|.6.2....3|.7..1..5.|5....9.6.|..6.2..3.|1..5...92|..7.9.41.|
</p>


<p>
|014060300|620004009|080050600|060200003|070010050|500009060|006020030|100500092|007090410|
</p>


<p>
014060300620004009080050600060200003070010050500009060006020030100500092007090410
</p>

</div>


</body>
</html>
HTML
}

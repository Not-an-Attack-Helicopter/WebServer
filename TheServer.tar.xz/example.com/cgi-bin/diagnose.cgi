#!/usr/bin/env bash

# ============================================================================
# Server Diagnostic
#
# A completely professional server diagnostic utility.
#
# Results may contain opinions.
# ============================================================================

export PATH="/run/current-system/sw/bin"


# ============================================================================
# Helper functions
# ============================================================================

check_ok()
{
    printf '<div class="check ok">[ OK ] %s</div>\n' "$1"
}

check_warn()
{
    printf '<div class="check warn">[ !! ] %s</div>\n' "$1"
}

check_fail()
{
    printf '<div class="check fail">[FAIL] %s</div>\n' "$1"
}


# ============================================================================
# Collect system information
# ============================================================================

UPTIME_MINUTES=$(awk '{print int($1 / 60)}' /proc/uptime)

LOAD=$(awk '{print $1}' /proc/loadavg)

MEM_TOTAL=$(awk '/^MemTotal:/ {print $2}' /proc/meminfo)

MEM_AVAILABLE=$(awk '/^MemAvailable:/ {print $2}' /proc/meminfo)

if [ "$MEM_TOTAL" -gt 0 ]; then
    MEM_USED=$((MEM_TOTAL - MEM_AVAILABLE))
    MEM_PERCENT=$((MEM_USED * 100 / MEM_TOTAL))
else
    MEM_PERCENT=0
fi

DISK_PERCENT=$(df -P / | awk 'NR==2 {gsub("%","",$5); print $5}')


# ============================================================================
# Determine problems
# ============================================================================

PROBLEMS=0

if awk "BEGIN {exit !($LOAD >= 4.0)}"; then
    PROBLEMS=$((PROBLEMS + 1))
fi

if [ "$MEM_PERCENT" -ge 90 ]; then
    PROBLEMS=$((PROBLEMS + 1))
fi

if [ "$DISK_PERCENT" -ge 90 ]; then
    PROBLEMS=$((PROBLEMS + 1))
fi


# ============================================================================
# CGI headers
# ============================================================================

printf '%s\n\n' 'Content-Type: text/html; charset=UTF-8'


# ============================================================================
# HTML header
# ============================================================================

cat <<'HTML'
<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="utf-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <link
        rel="icon"
        type="image/x-icon"
        href="/images/icons/favicon.ico"
    >

    <link
        rel="icon"
        type="image/png"
        sizes="32x32"
        href="/images/icons/favicon-32x32.png"
    >

    <link
        rel="icon"
        type="image/png"
        sizes="16x16"
        href="/images/icons/favicon-16x16.png"
    >

    <link
        rel="apple-touch-icon"
        sizes="180x180"
        href="/images/icons/apple-touch-icon.png"
    >

    <link
        rel="manifest"
        href="/images/icons/site.webmanifest"
    >

    <link
        rel="stylesheet"
        href="/css/diagnose.css"
    >

    <title>Server Diagnostic</title>

</head>

<body>

<div class="container">

    <h1>Server Diagnostic</h1>

    <div class="subtitle">
        Comprehensive Automated System Analysis
    </div>

    <div class="report">

HTML


# ============================================================================
# CPU / Load
# ============================================================================

cat <<'HTML'
<section>
    <h2>CPU / Load</h2>
HTML

if awk "BEGIN {exit !($LOAD < 1.0)}"; then

    check_ok "CPU load is perfectly reasonable."

elif awk "BEGIN {exit !($LOAD < 2.0)}"; then

    check_ok "CPU load is acceptable."

elif awk "BEGIN {exit !($LOAD < 4.0)}"; then

    check_warn "CPU load is elevated."

else

    check_fail "CPU load is becoming a lifestyle choice."

fi

echo '</section>'


# ============================================================================
# Memory
# ============================================================================

cat <<'HTML'
<section>
    <h2>Memory</h2>
HTML

if [ "$MEM_PERCENT" -lt 70 ]; then

    check_ok "Memory usage is healthy."

elif [ "$MEM_PERCENT" -lt 85 ]; then

    check_warn "Memory usage is somewhat elevated."

elif [ "$MEM_PERCENT" -lt 95 ]; then

    check_warn "Memory usage is concerning."

else

    check_fail "Memory appears to be mostly theoretical."

fi

echo '</section>'


# ============================================================================
# Disk
# ============================================================================

cat <<'HTML'
<section>
    <h2>Storage</h2>
HTML

if [ "$DISK_PERCENT" -lt 70 ]; then

    check_ok "Disk space is plentiful."

elif [ "$DISK_PERCENT" -lt 85 ]; then

    check_ok "Disk space is acceptable."

elif [ "$DISK_PERCENT" -lt 95 ]; then

    check_warn "Disk space is getting scarce."

else

    check_fail "The disk is approximately one email attachment away from disaster."

fi

echo '</section>'


# ============================================================================
# Uptime
# ============================================================================

cat <<'HTML'
<section>
    <h2>Uptime</h2>
HTML

if [ "$UPTIME_MINUTES" -lt 60 ]; then

    check_ok "System has been running for less than an hour."

elif [ "$UPTIME_MINUTES" -lt 10000 ]; then

    check_ok "System uptime is perfectly respectable."

elif [ "$UPTIME_MINUTES" -lt 50000 ]; then

    check_warn "System has been running for a considerable amount of time."

elif [ "$UPTIME_MINUTES" -lt 100000 ]; then

    check_warn "System uptime is becoming historically significant."

else

    check_fail "This server predates several configuration changes."

fi

echo '</section>'


# ============================================================================
# Kernel
# ============================================================================

cat <<'HTML'
<section>
    <h2>Kernel</h2>
HTML

if [ -r /proc/uptime ] && [ -r /proc/meminfo ]; then

    check_ok "Kernel information is available."

else

    check_fail "The kernel has declined to discuss its condition."

fi

echo '</section>'


# ============================================================================
# Overall assessment
# ============================================================================

cat <<'HTML'
<section class="conclusion">

    <h2>Overall Assessment</h2>

HTML

if [ "$PROBLEMS" -eq 0 ]; then

    cat <<'HTML'
    <div class="verdict good">
        SYSTEM STATUS: PROBABLY FINE
    </div>

    <p>
        No serious problems were detected.
    </p>

    <p>
        The server appears to be functioning normally.
    </p>
HTML

else

    cat <<HTML
    <div class="verdict bad">
        SYSTEM STATUS: CONCERNING
    </div>

    <p>
        Detected problem count: $PROBLEMS
    </p>

    <p>
        You should probably look into this.
    </p>
HTML

fi

echo '</section>'


# ============================================================================
# Additional analysis
# ============================================================================

cat <<'HTML'
<section class="analysis">

    <h2>Additional Analysis</h2>

HTML

SERVER_IS_JUDGING=0

RANDOM_RESULT=$((RANDOM % 8))

case "$RANDOM_RESULT" in

    0)
        echo '<p>The server appears to be judging you.</p>'
        SERVER_IS_JUDGING=1
        ;;

    1)
        echo '<p>The packets appear to be where they are supposed to be.</p>'
        ;;

    2)
        echo '<p>No suspicious squirrels were detected.</p>'
        ;;

    3)
        echo '<p>The system has declined to provide a personality profile.</p>'
        ;;

    4)
        echo '<p>Everything is fine. This statement has not been peer reviewed.</p>'
        ;;

    5)
        echo '<p>One process looked suspicious, but then behaved normally.</p>'
        ;;

    6)
        echo '<p>The server has requested that you stop refreshing this page.</p>'
        ;;

    7)
        echo '<p>The diagnostic has completed its investigation and found nothing it understands.</p>'
        ;;

esac

echo '</section>'


# ============================================================================
# Recommendations
# ============================================================================

cat <<'HTML'
<section class="recommendations">

    <h2>Recommended Actions</h2>

HTML

if [ "$SERVER_IS_JUDGING" -eq 1 ]; then

    echo '<p>Do not make eye contact.</p>'

elif [ "$PROBLEMS" -gt 0 ]; then

    echo '<p>Investigate the reported conditions.</p>'

else

    cat <<'HTML'
    <p>Do nothing.</p>

    <p>Seriously. It's working.</p>
HTML

fi

cat <<HTML

    <p class="small">
        Diagnostic uptime: $UPTIME_MINUTES minutes
    </p>

</section>

HTML


# ============================================================================
# Finish page
# ============================================================================

cat <<'HTML'

    </div>

</div>

</body>

</html>
HTML

#!/usr/bin/env python3

import os
import random
from urllib.parse import parse_qs
from html import escape


# ============================================================================
# Get the current excuse level.
#
# The level is carried in the URL, so there is no server-side state required.
# ============================================================================

query = os.environ.get("QUERY_STRING", "")
params = parse_qs(query)

try:
    level = int(params.get("level", ["0"])[0])
except (ValueError, TypeError):
    level = 0

level = max(0, level)


# ============================================================================
# Excuses
#
# The higher the level, the less believable the excuses become.
# ============================================================================

excuses = [

    # ------------------------------------------------------------------------
    # Level 1 — Reasonably plausible
    # ------------------------------------------------------------------------

    [
        "We're experiencing unusually high traffic.",
        "The database is under heavier load than expected.",
        "A network connection is currently experiencing some latency.",
        "We're investigating a temporary performance issue.",
        "The server is doing some routine maintenance.",
    ],

    # ------------------------------------------------------------------------
    # Level 2 — Getting suspicious
    # ------------------------------------------------------------------------

    [
        "The packets are taking the scenic route.",
        "The DNS server appears to be having a quiet afternoon.",
        "The database has decided to think about your request.",
        "One of the servers is being unusually philosophical.",
        "We're waiting for a particularly important packet.",
    ],

    # ------------------------------------------------------------------------
    # Level 3 — Clearly making things up
    # ------------------------------------------------------------------------

    [
        "The hamster responsible for DNS is on vacation.",
        "The cache has developed trust issues.",
        "A recursive loop has become emotionally attached to itself.",
        "The load balancer is currently balancing its workload on one foot.",
        "The server is waiting for the moon to reach the correct phase.",
    ],

    # ------------------------------------------------------------------------
    # Level 4 — Completely ridiculous
    # ------------------------------------------------------------------------

    [
        "The packets have formed a union and are negotiating better working conditions.",
        "Our primary server has challenged the backup server to a duel.",
        "The database refused to answer until someone apologized to it.",
        "The firewall has become convinced that the Internet is trying to get in.",
        "The routing table was briefly possessed by a Victorian ghost.",
    ],

    # ------------------------------------------------------------------------
    # Level 5 — There is no longer any attempt at professionalism
    # ------------------------------------------------------------------------

    [
        "The Internet is currently being held together with duct tape.",
        "A squirrel in Luxembourg has apparently unplugged something important.",
        "The packets have taken a wrong turn and are currently sightseeing.",
        "The server has achieved sentience but is refusing to cooperate.",
        "The cloud is raining. We're working on it.",
        "Someone accidentally divided by zero. We're still cleaning up.",
        "The IT department sacrificed a hard drive to the server gods.",
    ],
]


# ============================================================================
# Select the appropriate level.
# ============================================================================

if level == 0:
    excuse = "Click the button. I'll give you a perfectly legitimate explanation."

else:
    # Level 1 for first click, level 5 for sufficiently persistent users.
    index = min(level - 1, len(excuses) - 1)

    excuse = random.choice(excuses[index])


# ============================================================================
# Page title and commentary.
# ============================================================================

if level == 0:

    title = "Why Is The Website Slow?"
    commentary = "I'm sure there's a perfectly reasonable explanation."

elif level == 1:

    title = "Technical Explanation"
    commentary = "This is a completely legitimate excuse."

elif level == 2:

    title = "Technical Explanation"
    commentary = "Things are becoming slightly more complicated."

elif level == 3:

    title = "Technical Explanation"
    commentary = "We may be entering the realm of speculation."

elif level == 4:

    title = "Technical Explanation"
    commentary = "Management has been notified. Management is concerned."

else:

    title = "Technical Explanation"
    commentary = "At this point, we're just making things up."


# ============================================================================
# HTML output
# ============================================================================

print("Content-Type: text/html; charset=UTF-8")
print()

print(f"""<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="utf-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <link
        rel="icon"
        type="image/x-icon"
        href="/images/icons/favicon.ico"
    >

    <link
        rel="icon"
        type="image/png"
        sizes="32x32"
        href="/images/icons/favicon-32x32.png"
    >

    <link
        rel="icon"
        type="image/png"
        sizes="16x16"
        href="/images/icons/favicon-16x16.png"
    >

    <link
        rel="apple-touch-icon"
        sizes="180x180"
        href="/images/icons/apple-touch-icon.png"
    >

    <link
        rel="manifest"
        href="/images/icons/site.webmanifest"
    >

    <link
        rel="stylesheet"
        href="/css/excuse.css"
    >

    <title>Excuse Generator</title>

</head>

<body>

<div class="container">

    <h1>{escape(title)}</h1>

    <div class="excuse">
        {escape(excuse)}
    </div>

    <div class="commentary">
        {escape(commentary)}
    </div>

    <div class="level">
        Excuse level: {level}
    </div>

    <form method="get">

        <input
            type="hidden"
            name="level"
            value="{level + 1}"
        >

        <button type="submit">
            Generate Excuse
        </button>

    </form>

    <div class="reset">

        <a href="excuse.py">
            Start over
        </a>

    </div>

</div>

</body>

</html>
""")

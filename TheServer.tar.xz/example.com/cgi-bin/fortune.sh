#!/usr/bin/env bash

# ============================================================================
# Fortune Cookie Wisdom
#
# A highly sophisticated source of questionable life advice.
# ============================================================================

export PATH="/run/current-system/sw/bin"

FORTUNES=(
    "You will soon solve a problem by restarting the service."
    "A great opportunity is approaching. It is probably a maintenance window."
    "The answer you seek is in the logs."
    "You will find success after removing the semicolon you added yesterday."
    "Do not fear change. Fear the person who says, \"Let's rewrite it in Rust.\""
    "Your patience will be rewarded. Your patience will also be tested."
    "A wise administrator always has a backup. A wiser administrator has tested it."
    "You will soon discover that the problem was a DNS issue."
    "The path to enlightenment contains fewer dependencies."
    "Someone will ask you to make it look like the old website."
    "A mysterious error will disappear when you try to demonstrate it."
    "You are closer to the solution than you think. Unfortunately, you are looking in the wrong file."
    "Good things come to those who check the logs."
    "Your future is bright. Your terminal theme is not."
    "A forgotten cron job will reveal itself at an inconvenient time."
    "You will soon type a command perfectly on the first attempt. Nobody will be watching."
    "The server knows what you did."
    "Do not deploy on Friday. Unless you enjoy character development."
    "You will achieve great things after clearing the cache."
    "A small configuration change will have surprisingly large consequences."
    "The backup is probably fine."
    "Today is a good day to document something you will forget tomorrow."
    "Your next reboot will fix something you didn't know was broken."
    "The packets are taking the scenic route."
    "A recursive loop has become emotionally attached to itself."
    "You will soon encounter a problem caused by whitespace."
    "The universe has granted you sufficient permissions."
    "Someone has changed the configuration. Nobody knows who."
    "Your command will work perfectly immediately after you ask someone for help."
    "The machine is calm. Please do not touch anything."
    "You will soon understand why that service has been running since 2017."
    "A squirrel somewhere is probably not responsible for this."
    "Your future contains an unexpected reboot."
    "When in doubt, read the error message."
    "The error message is technically correct. It is also being deliberately unhelpful."
    "Today you will learn something important. Tomorrow you will forget where you learned it."
    "Your uptime is impressive. Your package updates are concerned."
    "There is wisdom in simplicity. There is also wisdom in having a rollback."
    "You will soon close a terminal window and immediately regret it."
    "The configuration file knows more than it is telling you."
    "Trust your instincts. Then check the logs."
    "Your next cup of coffee will solve nothing, but you will feel better."
    "The documentation exists. Somewhere."
    "You are destined for greatness. Please update your certificates first."
    "A clean rebuild may solve your problem. It may also create three new ones."
    "The server forgives you. The logs do not."
    "Your destiny is immutable."
    "You will soon find a typo that has been there for six months."
    "Everything is under control. This statement has not been peer reviewed."
)

# Pick a fortune.
INDEX=$((RANDOM % ${#FORTUNES[@]}))
FORTUNE="${FORTUNES[$INDEX]}"

# ============================================================================
# CGI response
# ============================================================================

printf '%s\n\n' 'Content-Type: text/html; charset=UTF-8'

cat <<HTML
<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="utf-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <link
        rel="icon"
        type="image/x-icon"
        href="/images/icons/favicon.ico"
    >

    <link
        rel="icon"
        type="image/png"
        sizes="32x32"
        href="/images/icons/favicon-32x32.png"
    >

    <link
        rel="icon"
        type="image/png"
        sizes="16x16"
        href="/images/icons/favicon-16x16.png"
    >

    <link
        rel="apple-touch-icon"
        sizes="180x180"
        href="/images/icons/apple-touch-icon.png"
    >

    <link
        rel="manifest"
        href="/images/icons/site.webmanifest"
    >

    <link
        rel="stylesheet"
        href="/css/fortune.css"
    >

    <title>Fortune Cookie</title>

</head>

<body>

<div class="container">

    <div class="cookie">
        🥠
    </div>

    <h1>Fortune Cookie</h1>

    <div class="fortune">
        $FORTUNE
    </div>

    <a class="button" href="fortune.sh">
        Crack another cookie
    </a>

</div>

</body>

</html>
HTML

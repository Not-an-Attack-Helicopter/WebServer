#!/usr/bin/env bash

# ============================================================================
# Server Mood
#
# Determines the emotional state of the server based on:
#
#   - uptime (in minutes)
#   - CPU load
#   - memory usage
#   - disk usage
#   - time of day
#   - a little randomness
#
# Because a server should have feelings.
# ============================================================================


# ============================================================================
# NixOS CGI environment
# ============================================================================

export PATH="/run/current-system/sw/bin"


# ============================================================================
# Basic system information
# ============================================================================

UPTIME_MINUTES=$(awk '{print int($1 / 60)}' /proc/uptime)

LOAD=$(awk '{print $1}' /proc/loadavg)

HOUR=$(date +%H)
HOUR=${HOUR#0}

if [ -z "$HOUR" ]; then
    HOUR=0
fi


# ============================================================================
# Memory usage
#
# Read MemTotal and MemAvailable from /proc/meminfo.
# ============================================================================

MEM_TOTAL=$(awk '/^MemTotal:/ {print $2}' /proc/meminfo)

MEM_AVAILABLE=$(awk '/^MemAvailable:/ {print $2}' /proc/meminfo)

if [ "$MEM_TOTAL" -gt 0 ]; then
    MEM_USED=$((MEM_TOTAL - MEM_AVAILABLE))
    MEM_PERCENT=$((MEM_USED * 100 / MEM_TOTAL))
else
    MEM_PERCENT=0
fi


# ============================================================================
# Disk usage
# ============================================================================

DISK_PERCENT=$(df -P / | awk 'NR==2 {gsub("%","",$5); print $5}')


# ============================================================================
# Start with a neutral mood.
# ============================================================================

MOOD="Content"
MESSAGE="Everything seems to be under control."


# ============================================================================
# CPU load
# ============================================================================

if awk "BEGIN {exit !($LOAD >= 8.0)}"; then

    MOOD="Terrified"
    MESSAGE="THE CPU HAS BECOME A FIRE."

elif awk "BEGIN {exit !($LOAD >= 4.0)}"; then

    MOOD="Panicking"
    MESSAGE="THE LOAD AVERAGE IS NOT A SUGGESTION."

elif awk "BEGIN {exit !($LOAD >= 2.0)}"; then

    MOOD="Stressed"
    MESSAGE="I have several things to do right now."

elif awk "BEGIN {exit !($LOAD >= 1.0)}"; then

    MOOD="Busy"
    MESSAGE="I'm working. Please don't make me work harder."

fi


# ============================================================================
# Memory pressure
#
# Memory can override a relatively calm CPU load.
# ============================================================================

if [ "$MEM_PERCENT" -ge 95 ]; then

    MOOD="Desperate"
    MESSAGE="MEMORY IS A CONCEPT I NO LONGER BELIEVE IN."

elif [ "$MEM_PERCENT" -ge 90 ]; then

    MOOD="Nervous"
    MESSAGE="We're running out of places to put things."

elif [ "$MEM_PERCENT" -ge 80 ]; then

    MOOD="Concerned"
    MESSAGE="Could someone please stop opening things?"

fi


# ============================================================================
# Disk pressure
# ============================================================================

if [ "$DISK_PERCENT" -ge 95 ]; then

    MOOD="Panicked"
    MESSAGE="THE DISK IS FULL. THIS IS NOT A DRILL."

elif [ "$DISK_PERCENT" -ge 90 ]; then

    MOOD="Worried"
    MESSAGE="There is technically still some disk space left."

elif [ "$DISK_PERCENT" -ge 80 ]; then

    MOOD="Uneasy"
    MESSAGE="We should probably stop storing things."

fi


# ============================================================================
# Uptime
#
# Uptime contributes flavour rather than completely determining the mood.
# ============================================================================

if [ "$UPTIME_MINUTES" -lt 5 ]; then

    MOOD="Confused"
    MESSAGE="I just woke up. What do you want?"

elif [ "$UPTIME_MINUTES" -lt 15 ]; then

    MOOD="Suspicious"
    MESSAGE="Why are you already asking me to do things?"

elif [ "$UPTIME_MINUTES" -lt 30 ]; then

    MOOD="Optimistic"
    MESSAGE="Everything is new and nothing has broken yet."

elif [ "$UPTIME_MINUTES" -ge 100000 ]; then

    # That's roughly 69 days.
    MOOD="Ancient"
    MESSAGE="I remember when this server was young."

elif [ "$UPTIME_MINUTES" -ge 50000 ]; then

    MOOD="Experienced"
    MESSAGE="I've been here longer than some of your processes."

elif [ "$UPTIME_MINUTES" -ge 10000 ]; then

    MOOD="Seasoned"
    MESSAGE="I've seen a thing or two."

fi


# ============================================================================
# Time of day
# ============================================================================

if [ "$HOUR" -ge 2 ] && [ "$HOUR" -lt 5 ]; then

    MOOD="Suspicious"
    MESSAGE="Why are you awake?"

elif [ "$HOUR" -ge 0 ] && [ "$HOUR" -lt 2 ]; then

    MESSAGE="$MESSAGE You should probably be asleep."

elif [ "$HOUR" -ge 5 ] && [ "$HOUR" -lt 7 ]; then

    MESSAGE="$MESSAGE It's too early for this."

fi


# ============================================================================
# Random personality
#
# Occasionally the server simply decides how it feels.
# This keeps the output from becoming completely predictable.
# ============================================================================

RANDOM_MOOD=$((RANDOM % 20))

if [ "$RANDOM_MOOD" -eq 0 ]; then

    MOOD="Philosophical"
    MESSAGE="What is uptime, really?"

elif [ "$RANDOM_MOOD" -eq 1 ]; then

    MOOD="Irritated"
    MESSAGE="Have you tried turning yourself off and on again?"

elif [ "$RANDOM_MOOD" -eq 2 ]; then

    MOOD="Suspicious"
    MESSAGE="Who told you about this server?"

elif [ "$RANDOM_MOOD" -eq 3 ]; then

    MOOD="Cheerful"
    MESSAGE="Everything is fine! Probably!"

fi


# ============================================================================
# Format uptime
#
# The underlying value remains MINUTES.
# ============================================================================

if [ "$UPTIME_MINUTES" -lt 60 ]; then

    UPTIME_TEXT="${UPTIME_MINUTES} minute(s)"

elif [ "$UPTIME_MINUTES" -lt 1440 ]; then

    HOURS=$((UPTIME_MINUTES / 60))
    MINUTES=$((UPTIME_MINUTES % 60))

    UPTIME_TEXT="${UPTIME_MINUTES} minutes (${HOURS}h ${MINUTES}m)"

else

    DAYS=$((UPTIME_MINUTES / 1440))
    HOURS=$(((UPTIME_MINUTES % 1440) / 60))
    MINUTES=$((UPTIME_MINUTES % 60))

    UPTIME_TEXT="${UPTIME_MINUTES} minutes (${DAYS}d ${HOURS}h ${MINUTES}m)"

fi


# ============================================================================
# CGI response
# ============================================================================

echo "Content-Type: text/html; charset=UTF-8"
echo

echo '<!DOCTYPE html>'
echo '<html lang="en">'

echo '<head>'
echo '    <meta charset="utf-8">'
echo '    <meta name="viewport" content="width=device-width, initial-scale=1.0">'
echo '    <link rel="icon" type="image/x-icon" href="/images/icons/favicon.ico">'
echo '    <link rel="icon" type="image/png" sizes="32x32" href="/images/icons/favicon-32x32.png">'
echo '    <link rel="icon" type="image/png" sizes="16x16" href="/images/icons/favicon-16x16.png">'
echo '    <link rel="apple-touch-icon" sizes="180x180" href="/images/icons/apple-touch-icon.png">'
echo '    <link rel="manifest" href="/images/icons/site.webmanifest">'
echo '    <link rel="stylesheet" href="/css/style.css">'
echo '    <title>Server Mood</title>'
echo '</head>'

echo '<body>'

echo '    <div class="container">'

echo '        <h1>Server Mood</h1>'

echo '        <div class="mood">'
echo "            $MOOD"
echo '        </div>'

echo '        <div class="message">'
echo "            \"$MESSAGE\""
echo '        </div>'

echo '        <div class="stats">'
echo "            Uptime: $UPTIME_TEXT<br>"
echo "            Load average: $LOAD<br>"
echo "            Memory used: $MEM_PERCENT%<br>"
echo "            Disk used: $DISK_PERCENT%"
echo '        </div>'

echo '    </div>'

echo '</body>'
echo '</html>'
